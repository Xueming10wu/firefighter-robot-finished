#include "lena_camera/V4L2Driver.h"

/*暂时封印的运算符重载，总有一天会重见广日的
void V4L2Driver::operator >> ( V4L2Driver &capture, cv::Mat &image )
{
    std::cout << " V4L2Driver >>" << std::endl;
    ioctl(fd,VIDIOC_DQBUF,&buf);
    buf.index = 0;
    cvmat = cvMat(IMAGEHEIGHT,IMAGEWIDTH,CV_8UC3,(void*)buffer);//CV_8UC3

    img = cvDecodeImage(&cvmat,1);

    if(!img)
    {
        std::cout <<"No img\n";
    }

    cvShowImage("one",img);

    cvReleaseImage(&img);

    ioctl(fd,VIDIOC_QBUF,&buf);

    if((cvWaitKey(1)&255) == 27)
    {
        exit(0);
    }

    image = cv::Mat(iplimg);
}*/


/*
V4L2Driver::V4L2Driver(int imagWidth, int imagHeight)
{
    std::cout << "V4L2Driver construct " << std::endl;
    openflag = false;
    //默认为0号端口，尺寸为 640x480
    setDevice( "/dev/video0" );
    setSize( 680, 480 );
}
*/

/*
V4L2Driver::V4L2Driver(const char* device)
{
    V4L2Driver();
    setDevice( device );
}
*/

V4L2Driver::V4L2Driver( char* device, int imagWidth, int imagHeight)
{
    setDevice( device );
    setImagWidth(imagWidth);
    setImagHeight(imagHeight);
}

V4L2Driver::~V4L2Driver()
{
    //free(device_port);
    ioctl(fd,VIDIOC_STREAMOFF,&type);
}

bool V4L2Driver::Open()
{
    if(!init_v4l2())
    {
        std::cout <<"Init fail~~\n";
        openflag = false;
        return false;
    }

    if(!v4l2_grab())
    {
        std::cout <<"grab fail~~\n";
        openflag = false;
        return false;
    }

    buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    buf.memory = V4L2_MEMORY_MMAP;
    openflag = true;
    return true;
}

bool V4L2Driver::Open(char* device)
{
    setDevice(device);
    return Open();
}

bool V4L2Driver::isOpened()
{
    return openflag;
}

cv::Mat V4L2Driver::readImage()
{
    std::cout << " V4L2Driver readImage" << std::endl;
    ioctl(fd,VIDIOC_DQBUF,&buf);
    buf.index = 0;
    cvmat = cvMat(IMAGEHEIGHT,IMAGEWIDTH,CV_8UC3,(void*)buffer);//CV_8UC3
    img = cvDecodeImage(&cvmat,1);
    if(!img)
    {
        std::cout <<"No img\n";
    }

    cvShowImage("one",img);
    cvReleaseImage(&img);

    ioctl(fd,VIDIOC_QBUF,&buf);
    if((cvWaitKey(1)&255) == 27)
    {
        exit(0);
    }
    opencvImage = cv::cvarrToMat(img);
    return opencvImage;
}


void V4L2Driver::setSize(int imagWidth, int imagHeight)
{
    setImagWidth(imagWidth);
    setImagHeight(imagHeight);
}

void V4L2Driver::setImagWidth(int imagWidth)
{
    IMAGEWIDTH = imagWidth;
}

void V4L2Driver::setImagHeight(int imagHeight)
{
    IMAGEHEIGHT = imagHeight;
}

void V4L2Driver::setDevice( char* device)
{
    std::cout << "setDevice" << std::endl;
    //重新设置device字符串
    int l = std::strlen(device);
    int s = std::strlen(device_port);

    if( s != 0 )
    {   
        std::cout << "device_port size : " << s << std::endl;
        delete []device_port;
    }
    device_port = new char[l+1];
    
    for(int i = 0; i < l; i ++)
    {
        device_port[i] = device[i];
    }

    device_port[l] = '\0';
    std::cout << "device_port : " << device_port << std::endl;
}

bool V4L2Driver::init_v4l2()
{
    if ((fd = open(device_port, O_RDWR)) == -1)
    {
        std::cout <<"Opening video device error\n";
        return false;
    }
    if (ioctl(fd, VIDIOC_QUERYCAP, &cap) == -1)
    {
        std::cout <<"unable Querying Capabilities\n";
        return false;
    }

    fmtdesc.index = 0;
    fmtdesc.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    std::cout <<"Support format: \n";
    while(ioctl(fd,VIDIOC_ENUM_FMT,&fmtdesc) != -1)
    {
        std::cout <<"\t%d. %s\n",fmtdesc.index+1,fmtdesc.description;
        fmtdesc.index++;
    }
    //set fmt
    fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    fmt.fmt.pix.width = IMAGEWIDTH;
    fmt.fmt.pix.height = IMAGEHEIGHT;
    fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_MJPEG; //*************************V4L2_PIX_FMT_YUYV****************
    fmt.fmt.pix.field = V4L2_FIELD_NONE;

    if (ioctl(fd, VIDIOC_S_FMT, &fmt) == -1)
    {
        std::cout <<"Setting Pixel Format error\n";
        return false;
    }
    if(ioctl(fd,VIDIOC_G_FMT,&fmt) == -1)
    {
        std::cout <<"Unable to get format\n";
        return false;
    }

    return true;
}

bool V4L2Driver::v4l2_grab()
{
    req.count = 1;
    req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    req.memory = V4L2_MEMORY_MMAP;

    if (ioctl(fd, VIDIOC_REQBUFS, &req) == -1)
    {
        std::cout <<"Requesting Buffer error\n";
        return false;
    }
    //5 mmap for buffers
    buffer = (uchar*)malloc(req.count * sizeof(*buffer));
    if(!buffer)
    {
        std::cout <<"Out of memory\n";
        return false;
    }
    unsigned int n_buffers;
    for(n_buffers = 0; n_buffers < req.count; n_buffers++)
    {
        //struct v4l2_buffer buf = {0};
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;
        buf.index = n_buffers;
        if(ioctl(fd, VIDIOC_QUERYBUF, &buf) == -1)
        {
            std::cout <<"Querying Buffer error\n";
            return false;
        }

        buffer = (uchar*)mmap (NULL, buf.length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, buf.m.offset);

        if(buffer == MAP_FAILED)
        {
            std::cout <<"buffer map error\n";
            return false;
        }
        std::cout <<"Length: " << buf.length << "\nAddress: " << buffer << "\n";
        std::cout <<"Image Length: " << buf.bytesused << "\n";
    }
    //6 queue
    for(n_buffers = 0; n_buffers <req.count; n_buffers++)
    {
        buf.index = n_buffers;
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP;
        if(ioctl(fd,VIDIOC_QBUF,&buf))
        {
            std::cout <<"query buffer error\n";
            return false;
        }
    }
    //7 starting
    type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
    if(ioctl(fd,VIDIOC_STREAMON,&type) == -1)
    {
        std::cout <<"stream on error\n";
        return false;
    }
    return true;
}
