#ifndef V4L2DRIVER_H
#define V4L2DRIVER_H

#include <errno.h>
#include <fcntl.h>
#include <linux/videodev2.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <opencv2/core/core.hpp>
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

#include <iostream>
#include <cstring>

using namespace std;
using namespace cv;
using cv::Mat;

class V4L2Driver
{
public:

    //V4L2Driver( int imagWidth = 640, int imagHeight = 480 );
    //V4L2Driver( const char* device );
    V4L2Driver( char* device, int imagWidth, int imagHeight );

    virtual ~V4L2Driver();

    bool Open();
    bool Open( char* device );

    bool isOpened();

    cv::Mat readImage();

    //暂时封印的运算符重载，总有一天会重见广日的
    //void operator >> ( V4L2Driver &capture, cv::Mat &image );

private:
    void setSize( int imagWidth, int imagHeight );
    void setImagWidth( int imagWidth );
    void setImagHeight( int imagHeight );
    void setDevice( char* device );
    bool init_v4l2();
    bool v4l2_grab();

    uchar *buffer;
    int IMAGEWIDTH;
    int IMAGEHEIGHT;
    char* device_port;
    int fd;
    bool openflag;

    CvMat cvmat;
    IplImage* img;
    cv::Mat opencvImage;

    struct v4l2_streamparm setfps;
    struct v4l2_capability cap;
    struct v4l2_fmtdesc fmtdesc;
    struct v4l2_format fmt,fmtack;
    struct v4l2_requestbuffers req;
    struct v4l2_buffer buf;
    enum   v4l2_buf_type type;
};



#endif
